import javax.swing.JOptionPane;
//Dillon Tall, CSC-229, Program 2
public class Project02 {

	public static void main(String[] args) {
		// Define Variables
		String firstName, lastName, address, city, state, zipCode;
		String input;
		
		int phoneCode = 0;
		String phoneName= "";
		double phoneCost= 0.0;
		int nServices = 0;
		
		
		
		//Additional Variables for Service Plan and Entertainment Service 
		String serviceName = "";
		double serviceCost = 0.0;
		String entertainmentName = "";
		double entertainmentCost = 0.0;
		
		//Final two variables for the end result in discount and final cost
		//To be printed in Final Cost of Services
		double discount = 0;
		double finCost = 0;

		//prompt user for personal information
		firstName = JOptionPane.showInputDialog(null,
				"Please Enter Your First Name:",
				"First Name",
				JOptionPane.QUESTION_MESSAGE
				);
		lastName = JOptionPane.showInputDialog(null,
				"Please Enter Your Last Name:",
				"Last Name",
				JOptionPane.QUESTION_MESSAGE
				);
		
		//Added required inputs asking for address, city, state and zipcode
		
		address = JOptionPane.showInputDialog(null,
				"Please Enter Your Address:",
				"Address",
				JOptionPane.QUESTION_MESSAGE
				);
		city = JOptionPane.showInputDialog(null,
				"Please Enter Your City:",
				"City name",
				JOptionPane.QUESTION_MESSAGE
				);
		state = JOptionPane.showInputDialog(null,
				"Please Enter Your State",
				"Two Letter State Code",
				JOptionPane.QUESTION_MESSAGE
				);
		zipCode = JOptionPane.showInputDialog(null,
				"Please Enter Your Zip Code",
				"Zip Code",
				JOptionPane.QUESTION_MESSAGE
				);
		//Service Plan Input Dialog Box added
		//Same as  Smart Phone InputDialog below with different cases
		input = JOptionPane.showInputDialog(null,
				"    Please Select Your Service Plan" +"\n" +
				"                   Monthly Cost      "+"\n" +
				"_______________________________________" + "\n" +
				"     Unlimited             " +"\n" +
				"     1. Start                           $34.00" +"\n" +
				"     2. Play More                  $58.00" +"\n" +
				"     3. Get More                   $68.00" +"\n" +
				" " + "\n" +
				"     Shared Data " +"\n" +
				"     4. S(5GB)                       $65.00" +"\n" +
				"     5. M(10GB)                    $75.00" +"\n" +
				"                                         " +"\n" +
				"     6. NO Service                       " +"\n" +
				"_______________________________________" + "\n" 
				
				,"Service Plan",
				JOptionPane.QUESTION_MESSAGE
				);
		phoneCode = Integer.parseInt(input);
		
		
		//Cases for Service Plan, used serviceName and serviceCost variables
		switch(phoneCode) {
			case 1:{
				serviceName = "Unlimited (Start)";
				serviceCost = 34.00;
				nServices++;
					
					
				break;
				}
			case 2:{
				serviceName = "Unlimited (Play More)";
				serviceCost = 58.00;
				nServices++;
				
				
				break;
			}
			case 3:{
				serviceName = "Unlimited (Get More)";
				serviceCost = 68.00;
				nServices++;
				
				
				break;
			}
			case 4:{
				serviceName = "Shared Data (S - 5G)";
				serviceCost = 65.00;
				nServices++;
				
				
				break;
			}
			case 5:{
				serviceName = "Shared Data (M - 10G)";
				serviceCost = 75.00;
				nServices++;
				
				
				break;
			}
			//Additional Case as there are more options in the Service Plan Input
			case 6:{
				serviceName = "NO Service";
				serviceCost = 0.0;
				
				
				
				break;
			}
			
		}
		
		
		
		
		// *** get the next personal info
		// prompt user for services
		input = JOptionPane.showInputDialog(null,
				"    Please Select Your Smart Phone" +"\n" +
				"       Price/ Month for 24 Months      "+"\n" +
				"_______________________________________________________" + "\n" +
				"     1 . Apple iPhone 14 Pro                             $98.35" +"\n" +
				"     2 . Samsung Galaxy S20 FE 5g UW          $73.55" +"\n" +
				"     3 . Google Pixel 6 Pro                               $45.75" +"\n" +
				"     4 . Motorola Moto g pure                          $38.55" +"\n" +
				"    " +"\n" +
				"     5 . NO Service" +"\n" +
				"_______________________________________________________" + "\n" 
				,"Smart Phone",
				JOptionPane.QUESTION_MESSAGE
				);
		phoneCode = Integer.parseInt(input);
		switch(phoneCode) {
			case 1:{
				phoneName = "Apple Iphone 14 Pro";
				phoneCost = 98.35;
				nServices++;
					
					
				break;
				}
			case 2:{
				phoneName = "Samsung Galaxy S20 FE 5g uW";
				phoneCost = 73.55;
				nServices++;
				
				
				break;
			}
			case 3:{
				phoneName = "Google Pixel 6 Pro ";
				phoneCost = 45.75;
				nServices++;
				
				
				break;
			}
			case 4:{
				phoneName = "Motorola Moto g pure ";
				phoneCost = 38.55;
				nServices++;
				
				
				break;
			}
			case 5:{
				phoneName = "No Service";
				phoneCost = 0.0;
				
				
				
				break;
			}
			
		}
		
		
		
		input = JOptionPane.showInputDialog(null,
				"    Please Select Your Entertainment Service" +"\n" +
				"                           Monthly Cost      "+"\n" +
				"__________________________________________________" + "\n" +
				"     1 . Disney                                        $7.99" +"\n" +
				"     2 . Hulu                                            $9.99" +"\n" +
				"     3 . Sports + Disney + Hulu            $12.99" +"\n" +
				" " +"\n" +
				"     4. NO Service                            " +"\n" +
				"__________________________________________________" + "\n" 
				,"Entertainment Service",
				JOptionPane.QUESTION_MESSAGE
				);
		phoneCode = Integer.parseInt(input);
		switch(phoneCode) {
			case 1:{
				entertainmentName = "Disney";
				entertainmentCost = 7.99;
				nServices++;
					
					
				break;
				}
			case 2:{
				entertainmentName = "Hulu";
				entertainmentCost = 9.99;
				nServices++;
				
				
				break;
			}
			case 3:{
				entertainmentName = "Sports + Disney + Hulu ";
				entertainmentCost = 12.99;
				nServices++;
				
				
				break;
			}
			case 4:{
				entertainmentName = "NO Service";
				entertainmentCost = 0.0;
				//no nServices++ 
				
				
				break;
			}
			
		}
		//Declaration of totalCost variable which is all of the costs combined
		double totalCost = serviceCost + phoneCost + entertainmentCost;
		//Used for discount and finCost calculation in below switch
		
		
		//Switch used instead of If statement to calculate the discount and final cost
		switch(nServices) {
		case 1:{
			discount = 0.0;
			finCost = totalCost;
			break;
			}
		/*finCost calculated by subtraction between the total cost and 
		 * the total cost multiplied by the discount
		 */
	
		case 2:{
			discount = 15.00;
			finCost = totalCost - (totalCost * 0.15);
			break;
		}
		case 3:{
			discount = 20.00;
			finCost = totalCost - (totalCost * 0.20);
			break;
		}
		}
		
		
		
		// Generate Invoice
		//Added the additional values to be printed in the dialog
		JOptionPane.showMessageDialog(null,
				"                                  CSC 229 - Project 2" + "\n" + 
						"__________________________________________________" + "\n" +
				"       First  Name  : " +firstName + "\n" +
		        "       Last Name:  : " +lastName + "\n" +
		        "       Address:     : " + address + "\n" +
		        "                          " + city + ", " + state + " " + zipCode + "\n" +
		        "__________________________________________________" + "\n" +
		        "                                  Service List "+ "\n" +
		        "__________________________________________________" + "\n" +
		        /*prints out all the plans selected and costs
		        Tried really hard to format and align the costs because 
		        of the changing variable names, should be close
		        */
		        " Phone                              : "+phoneName+"         ---"+phoneCost+ "\n" +
		        " Service Plan                   : "+serviceName+  "                ---"+serviceCost+ "\n" +
		        " Entertainment Service  : "+entertainmentName+    "                          ---"+entertainmentCost+ "\n" + 
		        "__________________________________________________" + "\n" +
		        //Final cost printed, used Math.round to print as whole number
		        "                                Total Cost    : $ " +Math.round(totalCost) + "\n" +
		        "                                % Discount  : % " +Math.round(discount) + "\n" +
		        "                                Final Cost:    : $ " + Math.round(finCost) + "\n" +
		        "__________________________________________________" + "\n" ,
		        "Final Cost of Services"
				, JOptionPane.INFORMATION_MESSAGE);
				
				
				
				
	}

}
