import javax.swing.JOptionPane;

public class Cube {
	//data members
	
	private int x;
	private int y;
	private int width;
	private int height;
	private int depth;
	  
	
	//constructors
	//no-arg
	public Cube() {
		x = 0;
		y = 0;
		width = 0;
		height = 0;
		depth = 0;
		
	}
	//arg-constructor
	public Cube(int a, int b, int c, int d, int e) {
		x = a;
		y = b;
		width = c;
		height = d;
		depth = e;
		
	}
	// accessors
	//get methods
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	} 
	
	
	public int getHeight() {
		return height;
	}
	public int getWidth() {
		return width;
		
	}
	public int getDepth() {
		return depth;
	}
	// other methods
		
	//I get a different calculation compared to the example, online calculator however
	//agrees with mine
	
	//surface area method
	//multiplied 6 by width to the power of 2
	//its the formula i found online, where any side ^ 2 * 6 is the area
	//unsure why the example had width and height different as all sides of cube are same
	public double getSurface() {
		return 6 * Math.pow(getWidth(), 2);
	}
	//volume method
	//again a formula i found online where V = a^3
	// a being any side (length width height) and I used width
	public double getVolume() {
		return Math.pow(getWidth(), 3);
		
	}
	public void getAttributes() {
		String input;
		//Input for X value
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"X-Coordinate of the TopLeft Corner",
				JOptionPane.QUESTION_MESSAGE);
		x = Integer.parseInt(input);
		//Input for Y Value
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Y-Coordinate of the Topleft Corner",
				JOptionPane.QUESTION_MESSAGE);
		y = Integer.parseInt(input);
		//input for width
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Width of the Cube ",
				JOptionPane.QUESTION_MESSAGE);
		width = Integer.parseInt(input);
		//input for height
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Height of the Cube ",
				JOptionPane.QUESTION_MESSAGE);
		height = Integer.parseInt(input);
		//input for depth
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Depth of the Cube",
				JOptionPane.QUESTION_MESSAGE);
		depth = Integer.parseInt(input);
		
	}
	public String toString() {
		//standard output 
		return "              Cube Properties " + "\n" +
				"_______________________________" + "\n" +
				" TopLeft Corner = (" +getX() + "," +getY()+ ")" +"\n" +
				"                  Width = " + getWidth() +"\n" +
				"                 Height = " + getHeight() +"\n" +
				"                  Depth = " + getDepth() +"\n" +
				"               Surface = " + getSurface() +"\n" +
				"                Volume = " + getVolume() +"\n" +
				"______________________________";
	}
}

