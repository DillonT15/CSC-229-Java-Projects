
import javax.swing.JOptionPane;
//Dillon Tall CSC-229
//Homework 1
public class Cylinder {
	//data members
	//for int x,y,radius and height
	private int x;
	private int y;
	private int radius;
	private int height;
	
	//constructors
	//no-arg
	public Cylinder() {
		x = 0;
		y = 0;
		radius = 0;
		height = 0;

		
	}
	//arg-constructor
	public Cylinder(int a, int b, int c, int d) {
		a = x;
		b = y;
		c = radius;
		d = height;

		
	}
	// accessors
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	} 
	public int getRadius() {
		return radius;
	}
	public int getHeight() {
		return height;
	}
	// other methods
		
	//getSurface for calculating surface area
	//Equation is 2pi * r * h + 2pi * r^2
	public double getSurface() {
		return 2 * Math.PI * radius * height + 2 * Math.PI * Math.pow(radius, 2);
	}
	
	//getVolume method for the volume
	//Used equation of:
	// Pi * r^2 * h
	public double getVolume() {
		
		return Math.PI * Math.pow(radius, 2) * height;
	}
	//get attributes method
	public void getAttributes() {
		String input;
		
		
		//input for first x value
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter X Coordinate ",
				JOptionPane.QUESTION_MESSAGE);
		x = Integer.parseInt(input);
		//input for y
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter Y Coordinate ",
				JOptionPane.QUESTION_MESSAGE);
		y = Integer.parseInt(input);
		//input for radius
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter the Radius ",
				JOptionPane.QUESTION_MESSAGE);
		radius = Integer.parseInt(input);
		//input for height
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter the Height",
				JOptionPane.QUESTION_MESSAGE);
		height = Integer.parseInt(input);
		
		
		
	}
	//to string method
	public String toString() {
		//output
		// same as rectangle output in project 4, changed variables
		return "              Diamond Properties " + "\n" +
				"_______________________________" + "\n" +
				"               Center = (" +x + "," +y+ ")" +"\n" +
				"                 Radius = " + getRadius() +"\n" +
				"               Height = " + getHeight() +"\n" +
				"         Surface Area = " + getSurface() + "\n" +
				"                  Volume = " + getVolume() +"\n" +
				"______________________________";
	}
}


