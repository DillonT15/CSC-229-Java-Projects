import javax.swing.JOptionPane;

public class RegularPolygon {
	//data members
	
	private int x;
	private int y;
	private int sides;
	private int radius;
	
	//constructors
	//no-arg
	public RegularPolygon() {
		x = 0;
		y = 0;
		sides = 0;
		radius = 0;
		
	}
	//arg-constructor
	public RegularPolygon(int a, int b , int c, int d) {
		x = a;
		y = b;
		sides = c;
		radius = d;
	
		
	}
	// accessors
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	} 
	public int getSides() {
		return sides;
	}
	public int getRadius() {
		return radius;
	}
	
	// other methods
		
	//side length method
	//returns 2r * sin(pi/s)
	//side length is used in below methods as well
	public double getSideLength() {
		return 2 * radius * Math.sin(Math.PI/sides);
	}
	//Perimeter is simply the amount of sides multiplied by their length
	public double getPerimeter() {
		return sides * getSideLength();
	}
	//Complicated formula found online
	//s * n^2 / 4 * Math.tan(pi/n)
	//had to use Math.tan for calculation
	public double getArea() {
		return (sides * Math.pow(getSideLength(), 2)) / (4 * Math.tan(Math.PI / sides));
	}
	public void getAttributes() {
		String input;
		
		//inputs
		//input for x
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter X (X Coordinate of the Center ",
				JOptionPane.QUESTION_MESSAGE);
		x = Integer.parseInt(input);
		//input for y
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter Y (Y Coordinate of the Center ",
				JOptionPane.QUESTION_MESSAGE);
		y = Integer.parseInt(input);
		//input for sides
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Number of Sides",
				JOptionPane.QUESTION_MESSAGE);
		sides = Integer.parseInt(input);
		//input for radius
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Radius of Bounding Circle",
				JOptionPane.QUESTION_MESSAGE);
		radius = Integer.parseInt(input);
		
		
	}
	public String toString() {
		//output
		//used a method called Math.ceil to round the answer up
		//Math.round used integer division to round down, while ceil rounds up
		//also used same Math.round equation as in triangle to round 2 decimal places for area
		return "              Regular Polygon Properties " + "\n" +
				"_______________________________" + "\n" +
				"               Center  = (" +x + "," +y+ ")" +"\n" +
				"               # Sides = " + getSides() +"\n" +
				"               Radius  = " + getRadius() +"\n" +
				"       Side Length = " + Math.ceil(getSideLength()) +"\n" +
				"           Perimeter = " + Math.ceil(getPerimeter()) +"\n" +
				"                    Area = " + Math.round(getArea() * 100.0) / 100.0 +"\n" +
				"______________________________";
	}
}
