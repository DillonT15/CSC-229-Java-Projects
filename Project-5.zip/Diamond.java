
import javax.swing.JOptionPane;

public class Diamond {
	//data members
	
	private int x;
	private int y;
	private int height;
	private int width;
	
	
	//constructors
	//no-arg
	public Diamond() {
		x = 0;
		y = 0;
		height = 0;
		width = 100;

		
	}
	//arg-constructor
	public Diamond(int a, int b, int c, int d) {
		a = x;
		b = y;
		c = height;
		d = width;

		
	}
	// accessors
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	} 
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return height;
	}
	// other methods
		
	//getArea method
	//Returns the width * height divided by 2
	public double getArea() {
		
		return (width * height) /2;
	}
	//Perimeter method
	//Equation found online which first calculates the side length:
	// Square root of (width / 2 )^2 + (height / 2)^2
	// Then multiplies by 4 as a diamond has 4 equal sides to get perimeter
	public double getPerimeter() {
		
		return Math.sqrt(Math.pow(width / 2, 2) + Math.pow(height/2, 2)) * 4;
	}
	public void getAttributes() {
		String input;
		
		//input
		//input for x
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter X (X Coordinate of the Center of the Diamond) ",
				JOptionPane.QUESTION_MESSAGE);
		x = Integer.parseInt(input);
		//input for y
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter Y (Y Coordinate of the Center of the Diamond) ",
				JOptionPane.QUESTION_MESSAGE);
		y = Integer.parseInt(input);
		//input for height
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter the Height of the Diamond ",
				JOptionPane.QUESTION_MESSAGE);
		height = Integer.parseInt(input);
		//input for width
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter the Width of the Diamond",
				JOptionPane.QUESTION_MESSAGE);
		width = Integer.parseInt(input);
		
		
		
	}
	public String toString() {
		//output
		//used math.round again like in triangle to round 2 decimal places
		//rest used get methods above
		return "              Diamond Properties " + "\n" +
				"_______________________________" + "\n" +
				"               Center = (" +x + "," +y+ ")" +"\n" +
				"                 Width = " + getWidth() +"\n" +
				"               Height = " + getHeight() +"\n" +
				"         Perimeter = " + Math.round(getPerimeter() * 100.0) / 100. +"\n" +
				"                  Area = " + getArea() +"\n" +
				"______________________________";
	}
}


