
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.Color;

public class Project05 extends Frame implements ActionListener
{
	//  Objects
	String command = "";
	// Objects of all classes
	Rectangle r;
	Triangle t;
	Diamond d;
	RegularPolygon p;
	//3d objects
	Cube c;
	Sphere s;
	
	// Extra Credit Objects
	
	
	Cylinder k;
	
	// Colors
	JColorChooser colorChooser = new JColorChooser();
	Color backgroundColor = new Color(0,0,0);
	Color foregroundColor = new Color(255,255,255);
		
	public static void main(String[] args)
	{
		Frame frame = new Project05();	
		frame.setResizable(true);
		frame.setSize(1000,840);
		frame.setVisible(true);
		
	}
	
	public Project05()
	{
		setTitle("Graphics");
		
		// Create Menu
		   			
		MenuBar mb = new MenuBar();
		setMenuBar(mb);
		
		Menu fileMenu = new Menu("File");
		mb.add(fileMenu);
		
		MenuItem miAbout = new MenuItem("About");
		miAbout.addActionListener(this);
		fileMenu.add(miAbout);
		
		MenuItem miColor = new MenuItem("Color");
		miColor.addActionListener(this);
		fileMenu.add(miColor);
		
		MenuItem miExit = new MenuItem("Exit");
		miExit.addActionListener(this);
		fileMenu.add(miExit);
		// 2D Shapes menu
		
		Menu twoDMenu = new Menu("2D Shapes");
		mb.add(twoDMenu);
		
		MenuItem miTriangle = new MenuItem("Triangle");
		miTriangle.addActionListener(this);
		twoDMenu.add(miTriangle);
		
		MenuItem miRectangle = new MenuItem("Rectangle");
		miRectangle.addActionListener(this);
		twoDMenu.add(miRectangle);
		
		MenuItem miDiamond = new MenuItem("Diamond");
		miDiamond.addActionListener(this);
		twoDMenu.add(miDiamond);
		
		MenuItem miPolygon = new MenuItem("Polygon");
		miPolygon.addActionListener(this);
		twoDMenu.add(miPolygon);

	
		
		// 3D Shapes Menu
		
		Menu threeDMenu = new Menu("3D Shapes");
		mb.add(threeDMenu);
		
		MenuItem miCube = new MenuItem("Cube");
		miCube.addActionListener(this);
		threeDMenu.add(miCube);
		
		MenuItem miSphere = new MenuItem("Sphere");
		miSphere.addActionListener(this);
		threeDMenu.add(miSphere);
		
		MenuItem miCylinder = new MenuItem("Cylinder");
		miCylinder.addActionListener(this);
		threeDMenu.add(miCylinder);
		
		// End program when window is closed
		
		WindowListener l = new WindowAdapter()
		{
						
			// window closed - exit program						
						public void windowClosing(WindowEvent ev)
						{
							System.exit(0);
						}
						// menu option selected - go to redraw and display method
						public void listener(WindowEvent ev)
						{
							repaint();
						}
						// window resized or refocused - redraw
						public void windowStateChanged(WindowEvent ev)
						{
							repaint();
						}
		
		};
		
		ComponentListener k = new ComponentAdapter()
		{
			public void componentResized(ComponentEvent e) 
			{
        		repaint();           
    		}
		};
		
		// register listeners
			
		this.addWindowListener(l);
		this.addComponentListener(k);

	}
	
//******************************************************************************
//  called by windows manager whenever the application window performs an action
//  (select a menu item, close, resize, ....
//******************************************************************************

public void actionPerformed (ActionEvent ev)
	{
	// figure out which command was issued
	
	command = ev.getActionCommand();
	
	// take action accordingly
	switch (command)
	{
	case "About":
	{
		repaint();
		break;
	}
	case "Exit":
	{
		System.exit(0);
	}
	case "Color":
	{
		backgroundColor = JColorChooser.showDialog(
									                     null,
									                     "Choose Background Color",
									                     colorChooser.getBackground());

		foregroundColor = JColorChooser.showDialog(
									                     null,
									                     "Choose Drawing Color",
									                     colorChooser.getBackground());
		repaint();
		break;
	}
	//Rectangle case
	case "Rectangle":
	{
		r = new Rectangle();
		r.getAttributes();
		repaint();
		
		break;
		
		
		
		
	}
	case "Triangle":
	{
		t = new Triangle();
		t.getAttributes();
		repaint();
		
		break;
		
		
		
		
	}
	case "Diamond":
	{
		d = new Diamond();
		d.getAttributes();
		repaint();
		
		break;
		
		
		
		
	}
	case "Polygon":
	{
		p = new RegularPolygon();
		p.getAttributes();
		repaint();
		
		break;
		
		
		
		
	}
	
	case "Cube":
	{
		c = new Cube();
		c.getAttributes();
		repaint();
		
		break;
		
		
		
		
	}
	case "Sphere":
	{
		s = new Sphere();
		s.getAttributes();
		repaint();
		
		break;
		
		
		
		
	}
	
	case "Cylinder":
	{
		k = new Cylinder();
		k.getAttributes();
		repaint();
		
		break;
		
		
		
		
	}
	
	}
}
//********************************************************
// called by repaint() to redraw the screen
//********************************************************
		
public void paint(Graphics g)
{
	
	// Check Command issued, take action accordingly
	switch(command)
	{
	case "About":
	{
		
		g.drawString(" Geometric Shapes",400, 100);
		g.drawLine (350,120, 550,120);
		g.drawString(" This program supports the entry of values of primary attributes and calculation of secondary " , 200, 140);
		g.drawString(" attributes (sides, angels, perimeter, area, surface, volume of the following shapes: " , 200, 160);
		g.drawString(" 1.      Triangle", 400, 200);
		g.drawString(" 2.      Rectangle", 400, 220);
		g.drawString(" 3.      Diamond", 400, 240);
		g.drawString(" 4.      Regular Polygon", 400, 260);
		g.drawString(" 5.      Cube", 400, 280);
		g.drawString(" 6.      Sphere", 400, 300);
		g.drawString(" 7.      Cylinder", 400, 320);
		break;
	}
	case "Color":
	{
		this.setBackground(backgroundColor);
		this.setForeground(foregroundColor);
		break;	
	}
	case "Rectangle":
	{
		
		int x = r.getxTopLeft();
		int y = r.getyTopLeft();
		int w = r.getWidth();
		int h = r.getHeight();
		g.drawString("Rectangle Properties", 100, 100);
		g.drawLine(70,120,240,120);
		g.drawString("TopLeft Corner", 80,140);
		g.drawString("= (" + x +"," + y + ")", 170, 140);
		g.drawString("Width", 80,160);
		g.drawString("= " + w, 170, 160);
		g.drawString("Height", 80,180);
		g.drawString("=" + h , 170, 180);
		g.drawString("Perimeter", 80,200);
		g.drawString("=" + r.getPerimeter(), 170, 200);
		g.drawString("Area", 80,220);
		g.drawString("=" + r.getArea(), 170, 220);
		//draw the border Rectangle
		g.drawRect(65, 80, 180, 150);
		// draw the shape
		g.drawRect(x, y, w, h);
		// draw Labels 
		g.drawString("(" + x + "," +y  + ")", x - 20, y -15);
		g.drawString(" " +w, x + w/2, y - 15);
		g.drawString(" " + h, x - 30, y +h/2);
		break;
	}
	case "Triangle":
	{
		
		int x = t.getX1();
		int x2 = t.getX2();
		int x3 = t.getX3();
		
		int y = t.getY1();
		int y2 = t.getY2();
		int y3 = t.getY3();
		g.drawString("Triangle Properties", 100, 100);
		g.drawLine(70,120,240,120);
		g.drawString("First Point", 80,140);
		g.drawString("= (" + x +"," + y + ")", 170, 140);
		g.drawString("Second Point", 80,160);
		g.drawString("= (" + x2 +"," + y2 + ")", 170, 160);
		g.drawString("Third Point", 80,180);
		g.drawString("= (" + x3 +"," + y3 + ")", 170, 180);
		g.drawString("Perimeter", 80,200);
		g.drawString("=" + t.getPerimeter(), 170, 200);
		g.drawString("Area", 80,220);
		g.drawString("=" + Round.roundDigits(t.getArea(),2), 170, 220);
		//draw the border Rectangle
		g.drawRect(65, 80, 180, 150);
		// draw the shape
		// simply plugged in x1-x3 and y1 - y3
		g.drawLine(x, y, x2, y2);
		g.drawLine(x2, y2, x3, y3);
		g.drawLine(x3, y3, x, y);
		// draw Labels 
		g.drawString("(" + x + "," +y  + ")", x - 20, y -15);
		g.drawString("(" + x2 + "," +y2  + ")", x2 - 20, y2 -15);
		g.drawString("(" + x3 + "," +y3  + ")", x3 - 20, y3 -15);

		break;
	}
	case "Diamond":
	{
		
	
		int x = d.getX();
		int y = d.getY();
		int h = d.getHeight();
		int w = d.getWidth();
		
		g.drawString("Diamond Properties", 100, 100);
		g.drawLine(70,120,240,120);
		g.drawString("Center Point", 80,140);
		g.drawString("= (" + x +"," + y + ")", 170, 140);
		g.drawString("Width", 80,160);
		g.drawString("= " + w, 170, 160);
		g.drawString("Height", 80,180);
		g.drawString("=" + h , 170, 180);
		g.drawString("Perimeter", 80,200);
		g.drawString("=" + Round.roundDigits(d.getPerimeter(),2), 170, 200);
		g.drawString("Area", 80,220);
		g.drawString("=" + Round.roundDigits(d.getArea(),2), 170, 220);
		//draw the border Rectangle
		g.drawRect(65, 80, 180, 150);
		// draw the shape
		//used width / 2 and height/2 to calculate the x and y values
		
		g.drawLine(x + (w/2), y, x - (w/2),y);
		g.drawLine(x, y - (h/2), x, y + (h/2));
		
		g.drawLine(x + (w/2), y, x ,y + (h/2));
		g.drawLine(x - (w/2), y, x ,y + (h/2));
		
		g.drawLine(x + (w/2), y, x ,y - (h/2));
		g.drawLine(x - (w/2), y, x ,y - (h/2));
		// draw Labels 
		g.drawString("(" + x + "," +y  + ")", x - 20, y -15);
		
		g.drawString(" " +w, x - w/4, y + 15);
		g.drawString(" " + h, x - w/8, y - h/4);

		break;
	}
	//unfinished polygon case, unable to draw
	case "Polygon":
	{
	
		int x = p.getX();
		int y = p.getY();
		int r = p.getRadius();
		int s = p.getSides();
		//created an array of strings called intArray
		String intArray[];
		intArray = new String[s];
		//side gap int created, this is for the output of the properties table
		//makes it so they are spaced depending on how many sides (s) are entered
		int sideGap = s * 20;
		//angle using 2/pi  / sides formula
		double angle = 2 * Math.PI / s;
		//for loop, goes through the number of sides, and attempts to calculate the angle
		//the "angle" is used to find the next vertice by multiplying it by i
		for(int i = 0; i < s; i++) {
			double a = i * angle;
			//created xAng and yAng variables to calculate the x and y coordinate of the
			//next vertice, didnt end up fully working
			int xAng = (int) (x + r * Math.cos(a));
			int yAng = (int) (y + r * Math.cos(a));
			//Going to the indice i in intArray, and replacing it or adding the vertices of
			// the x and y values (xAng and yAng) along with printing the points out
			intArray[i] = "Point " + (i + 1) + " = (" + xAng + "," + y + ")";
		}
		g.drawString("Polygon Properties", 100, 100);
		g.drawLine(70,120,240,120);
		g.drawString("Center Point", 80,140);
		g.drawString("= (" + x +"," + y + ")", 170, 140);
		g.drawString("Radius", 80,160);
		g.drawString("= " + r, 170, 160);
		g.drawString("# Sides", 80,180);
		g.drawString("=" + s , 170, 180);
		g.drawLine(70, 200, 240, 200);
		g.drawString("Vertices", 125,220);
		g.drawLine(70, 240, 240, 240);
		//for loop to print out all of the vertices in intArray above
		//multiplies i by 20 for each consecutive line
		for(int i = 0; i < s; i++) {
			g.drawString(intArray[i], 100, 260 +(i * 20));
		}
		//start using int sideGap to account for amount of points
		g.drawLine(70, 250 +sideGap, 240, 250+sideGap);
		
		g.drawString("Side", 80,260 +sideGap);
		g.drawString("=" + Round.roundDigits(p.getSideLength(),2), 170, 260+sideGap);
		g.drawString("Perimeter", 80,280+sideGap);
		g.drawString("=" + Round.roundDigits(p.getPerimeter(),2), 170, 280+sideGap);
		g.drawString("Area", 80,300+sideGap);
		g.drawString("=" + Round.roundDigits(p.getArea(),2), 170, 300+sideGap);
		//draw the border Rectangle
		g.drawRect(65, 80, 180, 310 +sideGap);
		
		// draw the shape
		
		
		// draw Labels 
		
		break;
	}
	
	
	case "Cube":
	{
		
		int x = c.getX();
		int y = c.getY();
		int w = c.getWidth();
		int h = c.getHeight();
		int d = c.getDepth();
		
		g.drawString("Cube Properties", 100, 100);
		g.drawLine(70,120,240,120);
		g.drawString("TopLeft Corner", 80,140);
		g.drawString("= (" + x +"," + y + ")", 170, 140);
		g.drawString("Width", 80,160);
		g.drawString("= " + w, 170, 160);
		g.drawString("Height", 80,180);
		g.drawString("=" + h , 170, 180);
		g.drawString("Depth", 80,200);
		g.drawString("=" + d , 170, 200);
		g.drawString("Surface Area", 80,220);
		g.drawString("=" + c.getSurface(), 170, 220);
		g.drawString("Volume", 80,240);
		g.drawString("=" + c.getVolume() , 170, 240);
		
		//draw the border Rectangle
		g.drawRect(65, 80, 180, 170);  
		// draw the shape
		g.drawRect(x, y, w, h);
		int xGap = w/4;
		int yGap = d/4;
		g.drawLine(x,y,x + xGap, y - yGap);
		g.drawLine(x +xGap, y - yGap, x + xGap+w, y - yGap);
		g.drawLine(x + xGap+w, y - yGap, x + w, y);
		
		
		g.drawLine(x + w,y + h,x + xGap + w, y - yGap + h);
		g.drawLine(x + xGap + w, y - yGap + h,x + xGap+w, y - yGap );
		// draw Labels 
		g.drawString("(" + x + "," +y  + ")", x - 20, y -15);
		g.drawString(" " +w, x + w/2, y - 15);
		g.drawString(" " + h, x - 30, y +h/2);
		
		g.drawString(" " + d, x + w, y - (yGap/2));
		break;
	}
	case "Sphere":
	{
		
		int x = s.getX();
		int y = s.getY();
		int r = s.getRadius();
		
		int w = r * 2;
	
		g.drawString("Sphere Properties", 100, 100);
		g.drawLine(70,120,240,120);
		g.drawString("Center", 80,140);
		g.drawString("= (" + x +"," + y + ")", 170, 140);
		g.drawString("Radius", 80,160);
		g.drawString("= " + r, 170, 160);
		g.drawString("Surface Area", 80,180);
		g.drawString("=" + Round.roundDigits(s.getSurface(),2), 170, 180);
		g.drawString("Volume", 80,200);
		g.drawString("=" + Round.roundDigits(s.getVolume(),2), 170, 200);

		
		//draw the border Rectangle
		g.drawRect(65, 80, 200, 150); 
		
		// draw the shape
		g.drawOval(x, y, w, w);
		
		g.drawOval(x , y + w/3,w,r/2);
		
		g.drawLine(x + r, y + r - 15, x, y + r - 15);
		// draw Labels 
		g.drawString("(" + x + "," +y  + ")", x + r , y + r);
		g.drawString(" " +r, x + r/2, y + r - 20);

		
		break;
	}
	case "Cylinder":
	{
		//implemented from the homework before
		int x = k.getX();
		int y = k.getY();
		int r = k.getRadius();
		int h = k.getHeight();
		//width variable
		int w = 2 * r;
		
	
		g.drawString("Cylinder Properties", 100, 100);
		g.drawLine(70,120,240,120);
		g.drawString("Base Center", 80,140);
		g.drawString("= (" + x +"," + y + ")", 170, 140);
		g.drawString("Radius", 80,160);
		g.drawString("= " + r, 170, 160);
		g.drawString("Height", 80,180);
		g.drawString("= " + h, 170, 180);
		g.drawString("Surface Area", 80,200);
		g.drawString("=" + Round.roundDigits(k.getSurface(),2), 170, 200);
		g.drawString("Volume", 80,220);
		g.drawString("=" + Round.roundDigits(k.getVolume(),2), 170, 220);

		
		//draw the border Rectangle
		g.drawRect(65, 80, 200, 150); 
		
		// draw the shape
		//this is the top oval
		g.drawOval(x, y - w/3, w, r/2);
		//bottom oval
		g.drawOval(x , y + w/3,w,r/2);
		
		//Radius line
		g.drawLine(x + r, y + r - 15, x + w, y + r - 15);
		
		//middle line
		g.drawLine(x + r, y + r - 15, x + r, y - 20);
		
		
		
		//side lines
		g.drawLine(x, y - r/2 + 7, x, y +r - 7);
		g.drawLine(x + w, y - r/2 + 7, x + w, y +r - 7);
		// draw Labels 
		g.drawString("(" + x + "," +y  + ")", x + r , y + r);
		g.drawString(" " +r, x + w - 30 , y + r - 20);
		g.drawString(" " +h, x + r + 10, y + r/3 );
		
		break;
	}
	}
}
		
}
 