import javax.swing.JOptionPane;

public class TwoDArray 
{
	private int[][] array;
	private int rows;
	private int columns;
	private int low;
	private int high;
	
public TwoDArray(int r, int c, int l, int h)
{
	rows = r;
	columns = c;
	low = l;
	high = h;
	array = new int[rows][columns];
	for (int i=0; i<rows; i++)
		for (int j=0; j<columns; j++)
    	array[i][j] = low + (int)((high-low+1)*Math.random());
}
public TwoDArray()
{
	rows = 10;
	columns = 10;
	low = 10;
	high = 99;
	array = new int[rows][columns];
	for (int i=0; i<rows; i++)
		for (int j=0; j<columns; j++)
    	  array[i][j] = low + (int)((high-low+1)*Math.random());
}
public void createArray()
{
	//input dialog for rows and columns
	String input = JOptionPane.showInputDialog(null,"Please enter an integer < 100:",
			"# Rows in Two-Dimensional Array",JOptionPane.QUESTION_MESSAGE);
    int size=Integer.parseInt(input);
    rows = size;
    input = JOptionPane.showInputDialog(null,"Please enter an integer < 100:",
			"# Columns in Two-Dimensional Array",JOptionPane.QUESTION_MESSAGE);
    int size2=Integer.parseInt(input);
    columns = size2;
    
    //input for low and high
    input = JOptionPane.showInputDialog(null,"Please enter an integer > 0:",
			"Lowest Value in the Array",JOptionPane.QUESTION_MESSAGE);
    low = Integer.parseInt(input);
    
    input = JOptionPane.showInputDialog(null,"Please enter an integer < 1000:",
			"Highest Value in the Array",JOptionPane.QUESTION_MESSAGE);
    high = Integer.parseInt(input);
    
    //creation of array using Math.random
    array = new int[rows][columns];
	for (int i=0; i<rows; i++)
		for (int j=0; j<columns; j++)
    	  array[i][j] = low + (int)((high-low+1)*Math.random());
    
}
public int getMaximum()
{
	int max = array[0][0];
	for (int i=0; i<rows; i++)
		for (int j=0; j<columns; j++)
		  if (max < array[i][j])
			   max = array[i][j];
	return max;
}
public int getMinimum()
{
	//flipped maximum
	int min = array[0][0];
	for (int i=0; i<rows; i++)
		for (int j=0; j<columns; j++)
		  if (min > array[i][j])
			   min = array[i][j];
	return min;
}
public double getAverage()
{
	double average = 0;
	// find total
	for (int i=0; i<rows; i++)
		for (int j=0; j<columns; j++)
			average += array[i][j];
	// calculate average
	//create an int size to get size of 2d array, divided sum (average) by the size
	int size = rows * columns;
	return average/size;
}
public int[][] getArray()
{
	return array;
}
public boolean search(int key)
{
	//traverse through 2d array using i j, compare to key 
	for (int i=0; i<rows; i++) {
		for (int j=0; j<columns; j++) {
			if(array[i][j] == key) {
				return true;
			}
	}
	}

	return false;
	
}

public int getColumns() { return columns;}
public int getRows() { return rows;}

public void shuffle()
{

	//traversal through 2d array using i and j
	for (int i=0; i<rows; i++) {
		for (int j=0; j<columns; j++) {
		//x and y variables used for random location
		//x is for the rows, y is for the columns
		int x = (int) (Math.random()*(rows));
		int y = (int) (Math.random()*(columns));
		//temporary variable, to be changed by the random
		int temp = array[i][j];
		//set the current indice of array to the randomly selected one using x and y
		array[i][j] = array[x][y];
		//set temp to the current i,j value
		array[x][y] = temp;
		}
	}
}

public void fill(int v)
{
	//goes through 2d array, sets each indice of i,j to v
	for (int i=0; i<rows; i++) {
		for (int j=0; j<columns; j++) {
			array[i][j] = v;
		}
		
		}
	// fill the entire array with v
}
}