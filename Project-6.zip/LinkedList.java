import java.util.Arrays;

import javax.swing.JOptionPane;

public class LinkedList 
{
	private Node head;
	private Node tail;
	private int size;
	private int low;
	private int high;
	
	public LinkedList()
	{
		head = null;
		tail = null;
		size = 0;
		low = 0;
		high = 0;
	}
	public LinkedList(Node h, Node t, int s, int l, int hi)
	{
		head = h;
		tail = t;
		size = s;
		low = l;
		high = hi;
	}
	public void createList()
	{
		String input = JOptionPane.showInputDialog(null,"Please enter an integer < 1000:",
				"Size of Linked List",JOptionPane.QUESTION_MESSAGE);
	    int s=Integer.parseInt(input);

	    input = JOptionPane.showInputDialog(null,"Please enter an integer > 0:",
				"Lowest Value in the List",JOptionPane.QUESTION_MESSAGE);
	    low = Integer.parseInt(input);
	    input = JOptionPane.showInputDialog(null,"Please enter an integer < 1000:",
				"Highest Value in the List",JOptionPane.QUESTION_MESSAGE);
	    high = Integer.parseInt(input);
	    
	    
	    for (int i=0; i<s; i++) {
	    	int k = low + (int)((high-low+1)*Math.random());
	    	addBegining(k);
	    
	}
	    
	}
	public Node getHead() {
		return head;
	}
	public Node getTail() {
		return tail;
	}
	public void addBegining(int v)
	{
		Node t = new Node();
		t.setData(v);
		t.setNext(null);
		if (head == null)
		{
			head = t;
			tail = t;
		}
		else
		{
			t.setNext(head);
			head = t;
		}
		size++;
	}
	//add end method
	public void addEnd(int v)
	{
		Node t = new Node();
		t.setData(v);
		t.setNext(null);
		
		if(tail == null) {
			head = t;
			tail = t;
		}
		else {
			tail.setNext(t);
			tail = t;
		}
		size++;
	}
	public boolean addByPosition(int v, int p)
	{
		//if position is at beginning (0) simply use addbegining
		if(p == 0) {
			addBegining(v);
		}
		//if position it as the end use addEnd
		else if(p == size) {
			addEnd(v);
		}
		else {
			//use setData on t a node variable
			Node t = new Node();
			t.setData(v);
			//node h used for the head of the linked list
			Node h = head;
			//for loop to get i to go through p (position)
			for(int i = 0; i < p - 1; i++) {
				//traverses the head using getNext until the position is found
				h = h.getNext();
			}
			//h is now one indice behind the desired position
			//set the next value of t to the next value of h
			t.setNext(h.getNext());
			h.setNext(t);
			//add one to the size
			size++;
		}
		return false;
	}
	public int getMinimum()
	{
		int min = head.getData();
		Node t = head;
		while (t != null)
		{
			if (min > t.getData())
				min = t.getData();
			t = t.getNext();
		}
		return min;
	}
	public int getMaximum()
	{
		int max = head.getData();
		Node t = head;
		while (t != null)
		{
			if (max < t.getData())
				max = t.getData();
			t = t.getNext();
		}
		return max;
	}
	public double getAverage()
	{
		double average = 0;
		Node t = head;
		//traverses each element while t != null
		while(t != null) {
			//averages adds each value in t
			average += t.getData();
			t = t.getNext();
		}
		
		return (double) average/size;
	}
	public boolean search(int key)
	{
		Node t = head;
		
		while(t != null) {
			//checks if current value at t is = to the key, returns true immediately if found
			if(t.getData() == key) {
				return true;
			}
			
			t = t.getNext();
		}
		return false;
	}
	
	
	
	public void sort()
	{
		int[] a = toArray();
		
		// sort a
		java.util.Arrays.sort(a);
		// create a new list pointed by head
		//set current head, tail and size to 0 to reset and create new list
		head = null;
		tail = null;
		size = 0;
		//goes through length of array, uses addEnd to create linked list with each indice
		for(int i = 0; i < a.length; i++) {
			addEnd(a[i]);
		}
	}
	
	public int[] toArray()
	{
		int[] t = new int[size];
		Node x = head;
		int index = 0;
		while(x != null)
		{
			t[index] = x.getData();
			index++;
			x = x.getNext();
		}
		return t;
	}
	
	public void shuffle()
	{
		//used same method as in OneDArray
		int[] array = toArray();
		// shuffle array
		for(int i=0; i<array.length; i++)
		{
			int j = (int) (Math.random()*(array.length));
			int temp = array[i];
			array[i] = array[j];
			array[j] = temp;
		}
		// convert array into a linked list
		head = null;
		tail = null;
		size = 0;
		for(int i = 0; i < array.length; i++) {
			addEnd(array[i]);
		}
		
		
		
		
	}
	public void fill(int v)
	{
		//creates an array like before to go through and fill
		
		int[] a = toArray();
		//fill the array
		for(int i = 0; i < a.length; i++) {
			a[i] = v;
		}
		//reset entire linked list
		head = null;
		tail = null;
		size = 0;
		//set the linked list to the array
		for(int i = 0; i < a.length; i++) {
			addEnd(a[i]);
		}
		}
		
	}
