import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JOptionPane;


public class Project06 extends Frame implements ActionListener
{
		
	String command = "";
	int key;
	boolean found;
	Font f = new Font("SansSerif",Font.BOLD,12);
	Font f1 = new Font("SansSerif",Font.BOLD,16);
	int v;
	int p;
	int[] temp;
	// define objects
	OneDArray originalArray;
	LinkedList list;
	TwoDArray original2D;
	
	public static void main(String[] args)
	{
		Frame frame = new Project06();	
		frame.setResizable(true);
		frame.setSize(1000,800);
		frame.setVisible(true);
	}
	
	public Project06()
	{
		setTitle("CSC 229 - Project 6 - 1D, 2D Arrays & Linked List");
		
		// Create Menu
		   			
		MenuBar mb = new MenuBar();
		setMenuBar(mb);
		
		Menu fileMenu = new Menu("File");
		mb.add(fileMenu);
		
		MenuItem miAbout = new MenuItem("About");
		miAbout.addActionListener(this);
		fileMenu.add(miAbout);
		
		MenuItem miExit = new MenuItem("Exit");
		miExit.addActionListener(this);
		fileMenu.add(miExit);
		
		Menu actionMenu = new Menu("One Dimensional Array");
		mb.add(actionMenu);
		
		MenuItem miCreate1D = new MenuItem("Create Array");
		miCreate1D.addActionListener(this);
		actionMenu.add(miCreate1D);
		
		Menu statsMenu1D = new Menu("Statistics");
		actionMenu.add(statsMenu1D);
		
		MenuItem miMinimum1D = new MenuItem("Array Minimum");
		miMinimum1D.addActionListener(this);
		statsMenu1D.add(miMinimum1D);
		
		MenuItem miMaximum1D = new MenuItem("Array Maximum");
		miMaximum1D.addActionListener(this);
		statsMenu1D.add(miMaximum1D);
		
		MenuItem miAverage1D = new MenuItem("Array Average");
		miAverage1D.addActionListener(this);
		statsMenu1D.add(miAverage1D);
		
		MenuItem miSort = new MenuItem("Sort Array");
		miSort.addActionListener(this);
		actionMenu.add(miSort);
		
		MenuItem miSearch1D = new MenuItem("Search Array");
		miSearch1D.addActionListener(this);
		actionMenu.add(miSearch1D);
		
		MenuItem miShuffle1D = new MenuItem("Shuffle Array");
		miShuffle1D.addActionListener(this);
		actionMenu.add(miShuffle1D);
		
		MenuItem miFill1D = new MenuItem("Fill Array");
		miFill1D.addActionListener(this);
		actionMenu.add(miFill1D);
		
	
		
		
		
		
		
		
		
		
		// Linked List
		Menu listMenu = new Menu("Linked List");
		mb.add(listMenu);
		
		MenuItem miCreateList = new MenuItem("Create List");
		miCreateList.addActionListener(this);
		listMenu.add(miCreateList);
		
		MenuItem miAddBegList = new MenuItem("Add To List Beginning");
		miAddBegList.addActionListener(this);
		listMenu.add(miAddBegList);
		
		MenuItem miAddEndList = new MenuItem("Add To List End");
		miAddEndList.addActionListener(this);
		listMenu.add(miAddEndList);
		
		MenuItem miAddPosList = new MenuItem("Add To List Position");
		miAddPosList.addActionListener(this);
		listMenu.add(miAddPosList);
		
		Menu statsMenuList = new Menu("List Statistics");
		listMenu.add(statsMenuList);
		
		MenuItem miMinimumList = new MenuItem("List Minimum");
		miMinimumList.addActionListener(this);
		statsMenuList.add(miMinimumList);
		
		MenuItem miMaximumList  = new MenuItem("List Maximum");
		miMaximumList.addActionListener(this);
		statsMenuList.add(miMaximumList);
		
		MenuItem miAverageList  = new MenuItem("List Average");
		miAverageList.addActionListener(this);
		statsMenuList.add(miAverageList);
		
		MenuItem miSortList = new MenuItem("Sort List");
		miSortList.addActionListener(this);
		listMenu.add(miSortList);
		
		MenuItem miSearchList = new MenuItem("Search List");
		miSearchList.addActionListener(this);
		listMenu.add(miSearchList);
		
		MenuItem miShuffleList = new MenuItem("Shuffle List");
		miShuffleList.addActionListener(this);
		listMenu.add(miShuffleList);
		
		MenuItem miFillList = new MenuItem("Fill List");
		miFillList.addActionListener(this);
		listMenu.add(miFillList);
		
		
		MenuItem miDisplayList = new MenuItem("Display List");
		miDisplayList.addActionListener(this);
		listMenu.add(miDisplayList);
		
		
		
		
		
		
		
		
		
		// 2D array (Matrix)
		
		Menu twoMenu = new Menu("Two Dimensional Array");
		mb.add(twoMenu);
		
		MenuItem miCreate2D = new MenuItem("Create Matrix");
		miCreate2D.addActionListener(this);
		twoMenu.add(miCreate2D);
		
		Menu statsMenu2D = new Menu("Statistics 2D");
		twoMenu.add(statsMenu2D);
		
		MenuItem miMinimum2D = new MenuItem("2D Array Minimum");
		miMinimum2D.addActionListener(this);
		statsMenu2D.add(miMinimum2D);
		
		MenuItem miMaximum2D = new MenuItem("2D Array Maximum");
		miMaximum2D.addActionListener(this);
		statsMenu2D.add(miMaximum2D);
		
		MenuItem miAverage2D = new MenuItem("2D Array Average");
		miAverage2D.addActionListener(this);
		statsMenu2D.add(miAverage2D);
		
		
		MenuItem miSearch2D = new MenuItem("2D Search Array");
		miSearch2D.addActionListener(this);
		twoMenu.add(miSearch2D);
	
		
		MenuItem miShuffle2D = new MenuItem("2D Shuffle Array");
		miShuffle2D.addActionListener(this);
		twoMenu.add(miShuffle2D);
		
		MenuItem miFill2D = new MenuItem("2D Fill Array");
		miFill2D.addActionListener(this);
		twoMenu.add(miFill2D);
		
		MenuItem mi2DDisplay = new MenuItem("2D Display");
		mi2DDisplay.addActionListener(this);
		twoMenu.add(mi2DDisplay);
		// End program when window is closed
		
		WindowListener l = new WindowAdapter()
		{
						
			// window closed - exit program						
						public void windowClosing(WindowEvent ev)
						{
							System.exit(0);
						}
						// menu option selected - go to redraw and display method
						public void listener(WindowEvent ev)
						{
							repaint();
						}
						// window resized or refocused - redraw
						public void windowStateChanged(WindowEvent ev)
						{
							repaint();
						}
		
		};
		
		ComponentListener k = new ComponentAdapter()
		{
			public void componentResized(ComponentEvent e) 
			{
        		repaint();           
    		}
		};
		
		// register listeners
			
		this.addWindowListener(l);
		this.addComponentListener(k);

	}
	
//******************************************************************************
//  called by windows manager whenever the application window performs an action
//  (select a menu item, close, resize, ....
//******************************************************************************

	public void actionPerformed (ActionEvent ev)
		{
			// figure out which command was issued
			
			command = ev.getActionCommand();
			
			// take action accordingly
		switch(command)
			{
		case "About":
			{
				repaint();
				break;
			}
		case "Exit":
			{
				System.exit(0);
				break;
			}
		case "Create Array":
			{
				originalArray = new OneDArray();
				originalArray.createArray();
				
				repaint();
				break;
			}
		case "Array Minimum":
		case "Array Maximum":
		case "Array Average":
  
			{
				
				repaint();
				break;
			}
		case "Sort Array":
			{
				repaint();
				break;
			}
		case "Search Array":
			{
				String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to Search for:",
						"Search Key",JOptionPane.QUESTION_MESSAGE);
			    key = Integer.parseInt(input);
				repaint();
				break;
			}
		case "Shuffle Array":
		{
			int k = originalArray.getArray().length;
			temp = new int[k];
			for(int i = 0; i < k; i ++ ) {
				temp[i] = originalArray.getArray()[i];
			}
			originalArray.shuffle();
			repaint();
			break;
		}
		case "Fill Array":
		{
			String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to Fill Array:",
					"Fill Value",JOptionPane.QUESTION_MESSAGE);
		    v = Integer.parseInt(input);
			repaint();
			break;
		}
		
	

		
		
		
		
		
	// Linked List Operations
		case "Create List":{
			list = new LinkedList();
			list.createList();
			repaint();
			break;
			
		}
		case "Add To List Beginning":{
			String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to add to the beginning:",
					"Add To List Beginning",JOptionPane.QUESTION_MESSAGE);
		    v = Integer.parseInt(input);
			repaint();
			break;
		}
	
		case "Add To List End":{
			String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to add to the end:",
					"Add To List End",JOptionPane.QUESTION_MESSAGE);
		    v = Integer.parseInt(input);
			repaint();
			break;
		}
		
		case "Add To List Position":{
			String input = JOptionPane.showInputDialog(null,"Please enter the Position:",
					"Position of New Node",JOptionPane.QUESTION_MESSAGE);
		    p = Integer.parseInt(input);
		    input = JOptionPane.showInputDialog(null,"Please enter the Value:",
					"Value of New Node",JOptionPane.QUESTION_MESSAGE);
			v = Integer.parseInt(input);
			
		    repaint();
			break;
		}
		case "List Minimum":
		case "List Maximum":
		case "List Average":
  
			{
				
				repaint();
				break;
			}
			
		case "Sort List":
		{
			repaint();
			break;
		}
		case "Search List":
		{
			String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to Search for:",
					"Search Key",JOptionPane.QUESTION_MESSAGE);
		    key = Integer.parseInt(input);
			repaint();
			break;
		}
		
		case "Shuffle List":
		{
		
		repaint();
		break;
		
		}
		case "Fill List":
		{
		String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to Fill List:",
				"Fill Value",JOptionPane.QUESTION_MESSAGE);
	    v = Integer.parseInt(input);
		
		repaint();
		break;
		}
		case "Display List":
		{
			repaint();
			break;
		}
			
		
		
		
		
		
			// 2D Array Operations
		case "Create Matrix":{
			original2D = new TwoDArray();
			original2D.createArray();
			repaint();
			break;
			
		}
		case "2D Array Minimum":
		case "2D Array Maximum":
		case "2D Array Average":
  
			{
				
				repaint();
				break;
			}
		case "2D Search Array":
		{
			String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to Search for:",
					"Search Key",JOptionPane.QUESTION_MESSAGE);
		    key = Integer.parseInt(input);
			repaint();
			break;
		}

		case "2D Shuffle Array":
		{
			
		repaint();
		break;
		}
		case "2D Fill Array":
		{
		String input = JOptionPane.showInputDialog(null,"Please enter an integer Number to Fill Array:",
				"Fill Value",JOptionPane.QUESTION_MESSAGE);
	    v = Integer.parseInt(input);
		repaint();
		break;
		}
		case"2D Display":{
			repaint();
		
		}
	
			}// end of switch
		}
//********************************************************
// called by repaint() to redraw the screen
//********************************************************
		
		public void paint(Graphics g)
		{
			
			// Check Command issued, take action accordingly
			int ww = this.getWidth();
			int h = this.getHeight();
			g.setFont(f);
			switch(command)
			{
			case "About": {
				System.out.println(h);
				g.drawString("This Program is designed to create a 1D Array, 2D Array, and Linked List. You can choose different functions to apply to the selected data type to change them" , 100, 90);
						g.drawString("You can create them by providing the size, followed by the lowest and highest value in the array. You will then be able to select each function in the drop down menu" , 100, 110);
						g.drawString("Here is all of the functions you can use to modify each data type:", 100, 140);
						g.drawString("One Dimensional Array: Sort, Search, Shuffle, Fill, Min Max and Average, Display   " , 100, 160);
						g.drawString("Linked List: Add, Sort, Create Array, Search, Shuffle, Fill, Min Max and Average, Display" , 100, 180);
						g.drawString("Two Dimensional Array: Create Matrix, Search, Shuffle, Fill, Min Max and Average, Display", 100, 200);
						g.drawString("At the bottom of each drop down menu you can display the current values of the selected data type", 220, 240);
				
						
						
						
				break;	
			}
			case "Create Array":
			{
				int x=100;
				int y = 100;
				int[] t = originalArray.getArray();
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				break;
			}

			case "Array Minimum":
			{
				int x=100;
				int y = 100;
				int[] t = originalArray.getArray();
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
				g.setFont(f1);
				g.setColor(Color.RED);
				g.drawString("Minimum = "+Integer.toString(originalArray.getMinimum()), ww/2-50, currentY+25);
				break;	
			}
			case "Array Maximum":
			{
				int x = 100;
				int y = 100;
				int currentY = displayArray(g,originalArray.getArray(),x,y,ww,"Original Array");
				g.setFont(f1);
				g.setColor(Color.red);
				currentY = currentY + 30;
				g.drawString("Maximum = " + originalArray.getMaximum(), ww/2-50, currentY);
				break;	
			}
			case "Array Average":
			{
				int x = 100;
				int y = 100;
				int currentY = displayArray(g,originalArray.getArray(),x,y,ww,"Original Array");
				g.setFont(f1);
				g.setColor(Color.red);
				currentY = currentY + 30;
				g.drawString("Average = " + Round.roundDigits(originalArray.getAverage(), 2), ww/2-50, currentY);
				break;		
			}
			case "Sort Array":
			{
				int x=100;
				int y = 100;
		// display original array
				int currentY = displayArray(g,originalArray.getArray(),x,y,ww,"Original Array");
		// Display the Sorted Array	
				originalArray.sort();
				x = 100;
				y = currentY + 25;
				currentY = displayArray(g,originalArray.getArray(),x,y,ww,"Sorted Array");
				break;
			}
			case "Search Array":
			{
				int x=100;
				int y = 100;
				int[] t = originalArray.getArray();
		// Display the Original Array
				int currentY = displayArray(g,t,x,y,ww,"Original Array");
		
		//Display the outcome of the search
				found = originalArray.search(key);
				g.setColor(Color.RED);
				g.setFont(f1);
				String result = "";
				if (found) result = "Found";
				else       result = "NOT Found";
				g.drawString("Search Key  **** "+Integer.toString(key)+" ****  " +result, ww/2-100, currentY+25);
				break;
			}
			case "Shuffle Array":
			{
				int x = 100;
				int y = 100;
				int currentY = displayArray(g,temp, x, y , ww, "Original Array");
				x = 100;
				y = currentY + 30;
				currentY = displayArray(g,originalArray.getArray(), x, y , ww, "Shuffled Array");

				break;
			}
			case "Fill Array":
			{
				int x = 100;
				int y = 100;
				int currentY = displayArray(g,originalArray.getArray(), x, y , ww, "Original Array");
				originalArray.fill(v);
				x = 100;
				y = currentY + 30;
				currentY = displayArray(g,originalArray.getArray(), x, y , ww, "Filled Array");

				break;
			}

			
	// Linked List Operations **************************************************************************
			case "Create List":
			{
				int x = 100;
				int y = 100;
				displayList(g, list, x, y, ww, "Original Linked List");
				System.out.println("****");
				break;
			}
			case "Add To List Beginning":
			{
				int x=100;
				int y = 100;
				Node t = list.getHead();
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				list.addBegining(v);
				x = 100;
				y = currentY + 30;
				currentY = displayList(g,list,x,y,ww,"New Linked List");
				break;
			}
			
			
			case "Add To List End":
			{
				int x=100;
				int y = 100;
		// Display the Original Array
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				list.addEnd(v);
				x = 100;
				y = currentY + 30;
				currentY = displayList(g,list,x,y,ww,"New Linked List");
				break;
			}
			
			case "Add To List Position":{
				int x=100;
				int y = 100;
				Node t = list.getHead();
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				list.addByPosition(v, p);
				x = 100;
				y = currentY + 30;
				currentY = displayList(g,list,x,y,ww,"New Linked List");
				break;
			}
			
			case "List Minimum":
			{
				int x=100;
				int y = 100;
				Node t = list.getHead();
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				g.setFont(f1);
				g.setColor(Color.RED);
				g.drawString("Minimum = "+Integer.toString(list.getMinimum()), ww/2-50, currentY+25);
				break;	
			}
			case "List Maximum":
			{
				int x=100;
				int y = 100;
				Node t = list.getHead();
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				g.setFont(f1);
				g.setColor(Color.RED);
				g.drawString("Maximum = "+Integer.toString(list.getMaximum()), ww/2-50, currentY+25);
				break;
			}
			case "List Average":
			{
				int x=100;
				int y = 100;
				Node t = list.getHead();
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				g.setFont(f1);
				g.setColor(Color.RED);
				g.drawString("Average = "+ Round.roundDigits(list.getAverage(), 2), ww/2-50, currentY+25);
				break;	
			}
			case "Sort List":
			{
				int x=100;
				int y = 100;
		// display original array
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
		// Display the Sorted Array	
				list.sort();
				x = 100;
				y = currentY + 25;
				currentY = displayList(g,list,x,y,ww,"Sorted List");
				break;
			}
			case "Search List":
			{
				int x=100;
				int y = 100;
				Node t = list.getHead();
		// Display the Original Array
				int currentY = displayList(g,list,x,y,ww,"Original List");
		
		//Display the outcome of the search
				found = list.search(key);
				g.setColor(Color.RED);
				g.setFont(f1);
				String result = "";
				if (found) result = "Found";
				else       result = "NOT Found";
				g.drawString("Search Key  **** "+Integer.toString(key)+" ****  " +result, ww/2-100, currentY+25);
				break;
			}
			case "Shuffle List":
			{
				int x = 100;
				int y = 100;
				
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				x = 100;
				y = currentY + 30;
				list.shuffle();
				currentY = displayList(g,list, x, y , ww, "Shuffled List");

				break;
			}
			case "Fill List":
			{
				int x = 100;
				int y = 100;
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				list.fill(v);
				x = 100;
				y = currentY + 30;
				currentY = displayList(g,list, x, y , ww, "Filled List");
				
				break;
			}
			case "Display List":
			{
				
				int x = 100;
				int y = 100;
				int currentY = displayList(g, list, x, y, ww, "Original Linked List");
				break;
			}
	// Matrix output
			
			case "Create Matrix":
			{
				
				int x= (ww-original2D.getColumns()*35)/2;
				int y = 75;
				int currentY = display2DArray( g, original2D,  x, y, ww, "Original Matrix");
				break;
			}
			
			case "2D Array Minimum":
			{
				int x=100;
				int y = 100;
				int currentY = display2DArray(g,original2D,x,y,ww,"Original Matrix");
				g.setFont(f1);
				g.setColor(Color.RED);
				g.drawString("Minimum = "+Integer.toString(original2D.getMinimum()), ww/2-50, currentY+25);
				break;	
			}
			case "2D Array Maximum":
			{
				int x=100;
				int y = 100;
				int currentY = display2DArray(g,original2D,x,y,ww,"Original Matrix");
				g.setFont(f1);
				g.setColor(Color.RED);
				g.drawString("Maximum = "+Integer.toString(original2D.getMaximum()), ww/2-50, currentY+25);
				break;	
			}
			case "2D Array Average":
			{
				int x=100;
				int y = 100;
				int currentY = display2DArray(g,original2D,x,y,ww,"Original Matrix");
				g.setFont(f1);
				g.setColor(Color.RED);
				g.drawString("Average = "+Round.roundDigits(original2D.getAverage(), 2), ww/2-50, currentY+25);
				break;		
			}
			case "2D Search Array":
			{
				int x=100;
				int y = 100;
				int currentY = display2DArray(g,original2D,x,y,ww,"Original Matrix");
		
		//Display the outcome of the search
				found = original2D.search(key);
				g.setColor(Color.RED);
				g.setFont(f1);
				String result = "";
				if (found) result = "Found";
				else       result = "NOT Found";
				g.drawString("Search Key  **** "+Integer.toString(key)+" ****  " +result, ww/2-100, currentY+25);
				break;
			}
			case "2D Shuffle Array":
			{
				int x = 100;
				int y = 100;
				int currentY = display2DArray(g,original2D, x, y , ww, "Original Matrix");
				original2D.shuffle();
				x = 100;
				y = currentY + 30;
				currentY = display2DArray(g,original2D, x, y , ww, "Shuffled Matrix");

				break;
			}
			case "2D Fill Array":
			{
				int x = 100;
				int y = 100;
				int currentY = display2DArray(g,original2D, x, y , ww, "Original Matrix");
				original2D.fill(v);
				x = 100;
				y = currentY + 30;
				currentY = display2DArray(g,original2D, x, y , ww, "Original Matrix");

				break;
			}
			case"2D Display":{
				int x = 100;
				int y = 100;
				int currentY = display2DArray(g,original2D, x, y , ww, "Original Matrix");
				
				break;
			}
			}// end of switch
			
			
			
		}
		public int displayArray(Graphics g, int[] a, int x, int y, int ww, String title)
		{
			g.setFont(f1);;
			g.setColor(Color.RED);
			g.drawString(title, ww/2-50, y);
			g.setFont(f);
			g.setColor(Color.BLACK);
			y = y + 25;
			
			int xs = x;
			for (int i=0; i<a.length; i++)
			{
				g.drawString(Integer.toString(a[i]), x , y);
				x = x + 35;
				if(x > ww-xs) {
					x = xs;
					y = y + 25;
				}
			}
			return y;
		}
		public int displayList(Graphics g, LinkedList l, int x, int y, int ww, String title)
		{
			g.setFont(f1);;
			g.setColor(Color.RED);
			g.drawString(title, ww/2-50, y);
			g.setFont(f);
			g.setColor(Color.BLACK);
			y = y + 25;
			
			int xs = x;
			Node t = list.getHead();
			while(t != null) {
			
				g.drawString(Integer.toString(t.getData()), x , y);
				//Draw Rectangle and Arrow Graphics between each value
				g.drawRect(x - 3, y - 12, 25, 15);
				g.drawLine(x + 25, y - 5, x + 30, y - 5);
				x = x + 35;
				if(x > ww-xs) {
					x = xs;
					y = y + 25;
				}
				t = t.getNext();
			}
			//Draw "End" String after the while loop
			g.drawString("End", x , y);
			return y;

		}
		public int display2DArray(Graphics g, TwoDArray t, int x, int y, int ww, String title)
		{
			g.setFont(f1);;
			g.setColor(Color.RED);
			g.drawString(title, ww/2-50, y);
			g.setFont(f);
			g.setColor(Color.BLACK);
			y = y + 25;
			
			int xs = x;
			int[][] a = t.getArray();
			for(int i = 0; i <a.length; i++) {
				for(int j = 0; j < a[i].length; j++) {
					//added rectangle to display boxes around each value
					g.drawRect(x - 5, y - 15, 35, 25);
					
					g.drawString(" " + a[i][j], x, y);
					x = x + 35;
				}
				x = xs;
				y = y + 25;
			}
			return y;
		}
	}