import javax.swing.JOptionPane;
//Dillon Tall, CSC 229
public class Project04 {
	public static void main(String[] args) {
		menu();
	}
	public static void menu() {
		JOptionPane.showMessageDialog(null,
		"   This application allows the user to select " +"\n" +		
		"   one of the six Shapes and enter the primary " +"\n" +
		"   attributes of the shape, it then calculates " +"\n" +
		"   the secondary attributes of the shape and " +"\n" +
		"          reports all attributes" +"\n" + 
	    "____________________________________________" + "\n" +
	    "               Two-Dimensional Shapes" + "\n" + 
	    "____________________________________________" + "\n" + 
		"                         1) Triangle" + "\n" +
		"                         2) Rectangle" + "\n" +
		"                         3) Diamond" + "\n" +
		"                         4) Regular Polygon" + "\n" +
	    "____________________________________________" + "\n" +
	    "               Three-Dimensional Shapes" + "\n" + 
	    "____________________________________________" + "\n" + 
		"                         5) Cube" + "\n" +
		"                         6) Sphere" + "\n" ,
		"Geometric Shapes" , JOptionPane.QUESTION_MESSAGE);
		
				
				
				
		String input;
		int selection = 0;
		int n;
		double result = 0.0;
		while(selection !=7)
		{
		input = JOptionPane.showInputDialog(null,
				"          CSC 229 - Project 04 (Geometric Shapes)" + "\n" + 
			    "____________________________________________" + "\n" + 
			    "                 Select a Shape by Entering" + "\n" + 
			    "            the Number Associated with Shape" + "\n" + 
			    "                 Press 7 to Exit the Program" + "\n" + 
			    "____________________________________________" + "\n" +
			    "               Two-Dimensional Shapes" + "\n" + 
			    "____________________________________________" + "\n" + 
				"                         1) Triangle" + "\n" +
				"                         2) Rectangle" + "\n" +
				"                         3) Diamond" + "\n" +
				"                         4) Regular Polygon" + "\n" +
			    "____________________________________________" + "\n" +
			    "               Three-Dimensional Shapes" + "\n" + 
			    "____________________________________________" + "\n" + 
				"                         5) Cube" + "\n" +
				"                         6) Sphere" + "\n" +
			    "____________________________________________" + "\n" +
			    "                         7) EXIT" + "\n" +
			    "____________________________________________" + "\n" , 
			    
				"CSC 229 - Project04 - Shapes",
				JOptionPane.QUESTION_MESSAGE);
				selection = Integer.parseInt(input);
				System.out.println("input = "+ selection);
				switch(selection) {
				
				case 1: //triangle
				{
					Triangle r = new Triangle();
					r.getAttributes();
					System.out.println(r.toString());
					displayResult(selection, r);
					break;
					
					
					
				}
				case 2: //Rectangle
				{
					Rectangle r = new Rectangle();
					r.getAttributes();
					System.out.println(r.toString());
					displayResult(selection, r);
					break;
				}
				case 3: //Diamond
				{
					Diamond r = new Diamond();
					r.getAttributes();
					System.out.println(r.toString());
					displayResult(selection, r);
					break;
				}
				case 4: //Regular Polygon
				{
					RegularPolygon r = new RegularPolygon();
					r.getAttributes();
					System.out.println(r.toString());
					displayResult(selection, r);
					break;
					
					
				}
				case 5: //Cube
				{
					Cube r = new Cube();
					r.getAttributes();
					System.out.println(r.toString());
					displayResult(selection, r);
					break;
					
					
			
				}
				case 6: //Sphere
				{
					Sphere r = new Sphere();
					r.getAttributes();
					System.out.println(r.toString());
					displayResult(selection, r);
					break;
				}
				case 7: //Exit
				{
					displayResult(selection, result);
					
					
					break;
				}
				//default case if a number inputed isnt between 1 and 7
				default: {
					JOptionPane.showMessageDialog(null, 
							"          Please Enter Numbers Between 1 and 7",
							"Incorrect Selection",
							JOptionPane.INFORMATION_MESSAGE);
				}
				}
		}
	}
				public static void displayResult(int selection, Object o) {
					switch(selection) {
					case 1: //triangle
					{
						JOptionPane.showMessageDialog(null,
								o.toString(),
								"Geometric Shapes",
								JOptionPane.INFORMATION_MESSAGE);
								
						break;
					}
					case 2: //rectangle
					{
						
						JOptionPane.showMessageDialog(null,
								o.toString(),
								"Geometric Shapes",
								JOptionPane.INFORMATION_MESSAGE);
								
						break;
				}
					case 3: //Diamond
					{
						
						JOptionPane.showMessageDialog(null,
								o.toString(),
								"Geometric Shapes",
								JOptionPane.INFORMATION_MESSAGE);
								
						break;
				}
					case 4: //Regular Polygon
					{
						
						JOptionPane.showMessageDialog(null,
								o.toString(),
								"Geometric Shapes",
								JOptionPane.INFORMATION_MESSAGE);
								
						break;
				}
					case 5: //Cube
					{
						
						JOptionPane.showMessageDialog(null,
								o.toString(),
								"Geometric Shapes",
								JOptionPane.INFORMATION_MESSAGE);
								
						break;
				}
					case 6: //Sphere
					{
						
						JOptionPane.showMessageDialog(null,
								o.toString(),
								"Geometric Shapes",
								JOptionPane.INFORMATION_MESSAGE);
								
						break;
				}
					case 7: // exit
					{
						JOptionPane.showMessageDialog(null, 
								"          Good Bye",
								"Thank You For Using Math Series",
								JOptionPane.INFORMATION_MESSAGE);
					}
					
					
					
					
				}
				
		}
	}

