import javax.swing.JOptionPane;

public class Sphere {
	//data members
	//only 3 used for sphere
	private int x;
	private int y;
	private int radius;
	
	//constructors
	//no-arg
	public Sphere() {
		x= 0;
		y = 0;
		radius = 0;
		
	}
	//arg-constructor
	public Sphere(int a, int b, int c) {
		x = a;
		y = b;
		radius = c;
		
	}
	// accessors
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	} 
	public int getRadius() {
		return radius;
	}
	
	// other methods
		
	//Surface method
	//Formula I found, 
	//multiply 4 by Pi * radius ^ 2
	public double getSurface() {
	 return 4 * Math.PI * Math.pow(radius, 2);
	}
	//Volume method
	//Another formula found
	//divided 4.0/3.0 (for double) multiply by pi and radius ^ 3
	public double getVolume() {
		return (4.0/3.0) * Math.PI * Math.pow(radius, 3);
				
	}
	public void getAttributes() {
		String input;
		
		//X input
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"X-Coordinate of the Center",
				JOptionPane.QUESTION_MESSAGE);
		x = Integer.parseInt(input);
		//Y input
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Y-Coordinate of the Center",
				JOptionPane.QUESTION_MESSAGE);
		y = Integer.parseInt(input);
		//radius input
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Radius",
				JOptionPane.QUESTION_MESSAGE);
		radius = Integer.parseInt(input);
		
		
	}
	public String toString() {
		//Output
		//I used Math.round at the end of surface area and volume
		//I did this to make it more concise and because there were a ton of extra digits
		return "              Sphere Properties " + "\n" +
				"_______________________________" + "\n" +
				"               Center = (" +x + "," +y+ ")" +"\n" +
				"               Radius = " + getRadius() +"\n" +
				"     Surface Area = " + Math.round(getSurface()) +"\n" +
				"               Volume = " + Math.round(getVolume()) +"\n" +
				"______________________________";
	}
}

