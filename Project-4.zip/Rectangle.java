import javax.swing.JOptionPane;

public class Rectangle {
	//data members
	
	private int xTopLeft;
	private int yTopLeft;
	private int width;
	private int height;
	
	//constructors
	//no-arg
	public Rectangle() {
		xTopLeft = 0;
		yTopLeft = 0;
		width = 100;
		height = 100;
	}
	//arg-constructor
	public Rectangle(int x, int y, int w, int h) {
		xTopLeft = x;
		yTopLeft = y;
		width = w;
		height = h;
	}
	// accessors
	public int getXTopLeft() {
		return xTopLeft;
	}
	public int getYTopLeft() {
		return yTopLeft;
	}
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return height;
	}
	// other methods
	public int getPerimeter() {
		return 2 * (width + height);
	}
	public int getArea() {
		return width * height;
	}
	public void getAttributes() {
		String input;
		
		//input for xTopLeft
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"TopLeft x-Coordinate of Rectangle ",
				JOptionPane.QUESTION_MESSAGE);
		xTopLeft = Integer.parseInt(input);
		
		//input for yTopLeft
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"TopLeft y-Coordinate of Rectangle ",
				JOptionPane.QUESTION_MESSAGE);
		yTopLeft = Integer.parseInt(input);
		
		//input for Width
		input = JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Width of Rectangle ",
				JOptionPane.QUESTION_MESSAGE);
		width = Integer.parseInt(input);
		
		//input for height
		input = JOptionPane.showInputDialog(null,
				"Please Enter a Positive Integer",
				"Height of Rectangle ",
				JOptionPane.QUESTION_MESSAGE);
		height = Integer.parseInt(input);
		
	}
	public String toString() {
		return "              Rectangle Properties " + "\n" +
				"_______________________________" + "\n" +
				"     Top Left Corner = (" +xTopLeft + "," +yTopLeft+ ")" +"\n" +
				"                       Width = " + width +"\n" +
				"                     Height = " + height +"\n" +
				"               Perimeter = " + getPerimeter() +"\n" +
				"                         Area = " + getArea() +"\n" +
				"______________________________";
	}
}
