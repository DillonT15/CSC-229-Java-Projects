import javax.swing.JOptionPane;

public class Triangle {
	//data members
	
	private int x1;
	private int y1;
	private int x2;
	private int y2;
	private int x3;
	private int y3;
	//distance formula and area variables
	//dist 1-3 for area and distance formulas
	private double dist1;
	private double dist2;
	private double dist3;
	private double perim;
	//side and area for calculating the area below
	private double side;
	private double area;
	
	//constructors
	//no-arg
	public Triangle() {
		x1 = 0;
		y1 = 0;
		x2 = 0;
		y2 = 100;
		x3 = 100;
		y3= 100;
		
	}
	//arg-constructor
	public Triangle(int a1, int b1, int a2, int b2, int a3, int b3) {
		x1 = a1;
		y1 = b1;
		x2 = a2;
		y2 = b2;
		x3 = a3;
		y3=  b3;
		
	}
	// accessors
	public int getX1() {
		return x1;
	}
	public int getY1() {
		return y1;
	} 
	
	// other methods
		
	//perimeter method
	public double getPerimeter() {
		//uses dist1 - dist3 and distance formula to find the 
		//distance between 2 points and add them to the overall perimeter
		dist1 = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
		dist2 = Math.sqrt(Math.pow(x2 - x3, 2) + Math.pow(y2 - y3, 2));
		dist3 = Math.sqrt(Math.pow(x3 - x1, 2) + Math.pow(y3 - y1, 2));
		perim = dist1 + dist2 + dist3;
		//return perimeter with an extra round to make it 2 decimals
		return Math.round(perim * 100.0) / 100.0;
	}
	//area method
	public double getArea() {
		dist1 = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
		dist2 = Math.sqrt(Math.pow(x2 - x3, 2) + Math.pow(y2 - y3, 2));
		dist3 = Math.sqrt(Math.pow(x3 - x1, 2) + Math.pow(y3 - y1, 2));
		// side (s) is dist1 - dist 3 divided by 2. Used in Heron formula
		side = (dist1 + dist2 + dist3) / 2;
		//Heron formula for calculating area with sides
		area = Math.sqrt(side * (side - dist1) * (side - dist2) * (side - dist3));
		
		
		
		
		return area;
	}
	public void getAttributes() {
		String input;
		
		//input for x1,x2,x3,y1,y2,y3
		//6 inputs total for user
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter X1 (X Coordinate of the First Point ",
				JOptionPane.QUESTION_MESSAGE);
		x1 = Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter Y1 (Y Coordinate of the First Point ",
				JOptionPane.QUESTION_MESSAGE);
		y1 = Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter X2 (X Coordinate of the Second Point ",
				JOptionPane.QUESTION_MESSAGE);
		x2 = Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter Y2 (Y Coordinate of the Second Point ",
				JOptionPane.QUESTION_MESSAGE);
		y2 = Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter X3 (X Coordinate of the Third Point ",
				JOptionPane.QUESTION_MESSAGE);
		x3 = Integer.parseInt(input);
		input = JOptionPane.showInputDialog(null,
				"Please Enter an Integer",
				"Enter Y3 (X Coordinate of the Third Point ",
				JOptionPane.QUESTION_MESSAGE);
		y3 = Integer.parseInt(input);
		
	}
	public String toString() {
		//output showing getPerimeter, getArea and the 3 points x1,2,3 - y1,2,3
		return "              Triangle Properties " + "\n" +
				"_______________________________" + "\n" +
				"               Point 1      = (" +x1 + "," +y1+ ")" +"\n" +
				"               Point 2      = (" +x2 + "," +y2+ ")" +"\n" +
				"               Point 3      = (" +x3 + "," +y3+ ")" +"\n" +
				"               Perimeter = " + getPerimeter() +"\n" +
				"               Area          = " + getArea() +"\n" +
				"______________________________";
	}
}

