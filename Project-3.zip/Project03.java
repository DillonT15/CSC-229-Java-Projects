import javax.swing.JOptionPane;
//Dillon Tall, CSC- 229
public class Project03 {
	public static void main(String[] args) {
		menu();
	}
	public static void menu() {
		//declared variables
		String input;
		int selection = 0;
		int n;
		double result = 0.0;
		
		while(selection !=5) {
		input = JOptionPane.showInputDialog(null,
				"                CSC 229 - Project 03 (Math Series)" + "\n" + 
			    "__________________________________________________" + "\n" + 
				"  Select a series by pressing the number key Associated" + "\n" +
				"                   			       5 to Exit the program" + "\n" + 
				"__________________________________________________" + "\n" + 
				"                         1) 1+2+3         + ........ + N" + "\n" + 
				"                         2) 1+8+27       + ........ + N^3" + "\n" +
				"                         3) 4+16+64     + ........+ 4^N" + "\n" +
				"                         4) 2/1!+4/2!     + ....... + 2^N/N!" + "\n" +
				" " + "\n" +
				"                         5) EXIT" + "\n" +
				"__________________________________________________" + "\n" ,
				"Math Series",
				JOptionPane.QUESTION_MESSAGE);
				selection = Integer.parseInt(input);
				System.out.println("input = "+ selection);
				switch(selection) {
				
				case 1:
				{
					input = JOptionPane.showInputDialog(null,
							"Please Enter a Positive Integer for N",
							"1+2+3+...+N",
							JOptionPane.QUESTION_MESSAGE);
					n = Integer.parseInt(input);
					result = m1(n);
					displayResult(selection, n, result);
					
					break;
				}
				
				//created additional cases below
				//same code as case 1 but instead of m1 calls
				//m2 - m4 for their seperate calculations
				case 2:
				{
					input = JOptionPane.showInputDialog(null,
							"Please Enter a Positive Integer for N",
							"1+8+27+...+N^3",
							JOptionPane.QUESTION_MESSAGE);
					n = Integer.parseInt(input);
					result = m2(n);
					displayResult(selection, n, result);
					
					break;
					
				}
				case 3:
				{
					input = JOptionPane.showInputDialog(null,
							"Please Enter a Positive Integer for N",
							"4+16+64+...+4^N",
							JOptionPane.QUESTION_MESSAGE);
					n = Integer.parseInt(input);
					result = m3(n);
					displayResult(selection, n, result);
					break;
				}
				case 4:
				{
					input = JOptionPane.showInputDialog(null,
							"Please Enter a Positive Integer for N",
							"2/1!+4/2!+8/3+...+2^N/N!",
							JOptionPane.QUESTION_MESSAGE);
					n = Integer.parseInt(input);
					result = m4(n);
					displayResult(selection, n, result);
					break;
				}
				case 5:
				{
					//displays the goodbye message and ends
					displayResult(selection,0,0);
					break;
					
				}
				default:
					JOptionPane.showMessageDialog(null, 
							"          Please Enter Numbers Between 1 and 5",
							"Incorrect Selection",
							JOptionPane.INFORMATION_MESSAGE);
				}
				
		}
	}
	//displays results of each function
	public static void displayResult(int selection, int n, double result) {
		switch(selection) {
		
		//added Math.round to the result of first 3 cases as specified
		
		case 1:{
		
			JOptionPane.showMessageDialog(null, 
		"          CSC 229 - Project 03 (Math Series)" + "\n" + 
		"		__________________________________________________" + "\n" +
		"                1 + 2 + 3 + ..... + " +n+" = " + Math.round(result) + "\n" +
		"		__________________________________________________" + "\n" ,
		"Math Series",
		JOptionPane.INFORMATION_MESSAGE);
					
			break;
			
		}
		
		
		//replaced + n + from case 1 with the proper variable
		//for each case. It is also rounded with Math.round
		// for example, case 2 prints +Math.pow(n,3)+ instead of just n
		case 2:{
			//added Math.pow for N for the display
			JOptionPane.showMessageDialog(null, 
		"          CSC 229 - Project 03 (Math Series)" + "\n" + 
		"		__________________________________________________" + "\n" +
		"                1 + 8 + 27  ..... + " +Math.round(Math.pow(n, 3))+" = " + Math.round(result) + "\n" +
		"		__________________________________________________" + "\n" ,
		"Math Series",
		JOptionPane.INFORMATION_MESSAGE);
					
			break;
			
		}
		case 3:{
			
			JOptionPane.showMessageDialog(null, 
		"          CSC 229 - Project 03 (Math Series)" + "\n" + 
		"		__________________________________________________" + "\n" +
		"                4 + 16 + 64  ..... + " +Math.round(Math.pow(4, n))+" = " + Math.round(result) + "\n" +
		"		__________________________________________________" + "\n" ,
		"Math Series",
		JOptionPane.INFORMATION_MESSAGE);
					
			break;
			
		}
		case 4:{
			//I used a (float) cast on the result to round the digits
			//as specified
		JOptionPane.showMessageDialog(null, 
		"          CSC 229 - Project 03 (Math Series)" + "\n" + 
		"		__________________________________________________" + "\n" +
		"                2/1! + 4/2! + 8/3! + ..... +  " + Math.round(Math.pow(2,n)) + "/" + n + "!" + " = " + (float)(result) + "\n" +
		"		__________________________________________________" + "\n" ,
		"Math Series",
		JOptionPane.INFORMATION_MESSAGE);
					
			break;
			
		}
		
		
		case 5:{
			//case 5 for printing goodbye and ending code
			JOptionPane.showMessageDialog(null, 
					"          Good Bye",
					"Thank You For Using Math Series",
					JOptionPane.INFORMATION_MESSAGE);
		
		}
		
		
			
			
		
	}
	}
	public static double m1(int n){
		double sum = 0.0;
		for(int i = 1; i <= n; i++) {
			sum = sum + i;
		}
		System.out.println("sum = " + sum);
		return sum;
	}
	
	
	//created m2 - m4 for the other equations
	public static double m2(int n){
		double sum = 0.0;
		
		for(int i = 1; i <= n; i++) {
			//the sum adds each i to the power of 3
			sum = sum + Math.pow(i, 3);
		}
		System.out.println("sum = " + sum);
		return sum;
	}
	public static double m3(int n){
		double sum = 0.0;
		
		for(int i = 1; i <= n; i++) {
			//calculates and adds 4 to the i to sum
			sum = sum + Math.pow(4, i);
		}
		System.out.println("sum = " + sum);
		return sum;	
				
	}
	public static double m4(int n){
		 double sum = 0.0;
		for(int i = 1; i <= n; i++) {
			//calls fact method that I created below
			sum = sum + (Math.pow(2, i) / fact(i) );
		}
		System.out.println("sum = " + sum);
		

		return sum;
	}
	//factorial method
	public static double fact(int n) {
		//temporary x variable to calculate factorial below
		double x = 1.0;
	
		//calculates the factorial of n provided
		for(int i = 1; i<= n; i++) {
			x = x * i;
		}
		//returns x after the for loop calculation
		return x;
	}
	
}
	
